import pysftp
import os
import subprocess
import time
import zipfile

# sftp settings.
sftpHost = '192.168.0.14'
sftpUser = 'root'
sftpPassword = 'clado123'
sftpBackupDirectory = '/backup'


# domain document-root 
domainRoot = '/home/hackme/Desktop/works/backupScript/domain'
tempDir = '/home/hackme/Desktop/works/backupScript/temp'

#Clear Screen - START
def fun_makeHeader(msg):
    subprocess.call('clear',shell=True)
    print('')
    print('',msg.upper())
    print('','-' * len(msg))
    print('')

def fun_makeMessage(msg):
    print('')
    print('',msg.upper())
    input('')

   

def fun_makeArchive(backDomainName):
    fun_makeHeader('progress of backup '+backDomainName)

    ######################################
    # Archiving Process.
    ######################################  
    try:
        print(' - STARTING THE ARCHIVING PROCESS ', end='')
        timeStamp = time.strftime("%d-%b-%Y-%H-%M-%S")
        backFileName = tempDir+'/'+backDomainName+'-'+timeStamp+'.zip'
        zipObj = zipfile.ZipFile(backFileName,'w')
        os.chdir(domainRoot)
        for rootDir,subDirs,subFiles in os.walk(backDomainName):
            for directory in subDirs:
                zipObj.write(os.path.join(rootDir,directory))
            for content in subFiles:
                zipObj.write(os.path.join(rootDir,content))
        zipObj.close()
        print('[ Complted ]')
    except:
        print('[ Failed ]')

    ###################################
    # Copying Backup file to the remote server.
    ###################################
    try:
        print(' - COPYING BACKUP FILE TO REMOTE SERVER ', end = '' )
        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None   
        with pysftp.Connection(sftpHost, username=sftpUser , password=sftpPassword , cnopts=cnopts) as sftp: 
            if not sftp.exists(sftpBackupDirectory):
                sftp.mkdir(sftpBackupDirectory)
                sftp.chmod(sftpBackupDirectory,mode=700)
     
            sftp.chdir(sftpBackupDirectory)
            if not sftp.exists(backDomainName):
                sftp.mkdir(backDomainName)
                sftp.chdir(backDomainName)
                sftp.put(backFileName)
            else:
                sftp.chdir(backDomainName)
                sftp.put(backFileName)                             
        print('[ Completed ]') 
    except:
        print('[ Failed ]')  


      

def fun_createBackup():
    fun_makeHeader('select the domain to backup')
    # Listing the domainRoot , proceed only if it's not empty.
    domains = os.listdir(domainRoot)
    if domains:
        for domain in domains:
            print(' -',domain)
        print('')
        # backDomainName eg: google.com 
        backDomainName = input(' Select a Domain Name : '.upper())
        # Checking the variable is not empty.
        if backDomainName:
            # archivePath domainRoot/google.com
            absArchivePath = os.path.join(domainRoot,backDomainName)
            #print(archivePath)
            if os.path.exists(absArchivePath):
                fun_makeArchive(backDomainName)            
            else:    
                fun_makeMessage('no such domain '+backDomainName)
        else:
            fun_makeMessage('empty selection')


def fun_listBackup():
    fun_makeHeader('listing all domain remote backups')
    try:
        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None       
        with pysftp.Connection(sftpHost, username=sftpUser , password=sftpPassword , cnopts=cnopts) as sftp:
            if sftp.exists(sftpBackupDirectory): 
                sftp.chdir(sftpBackupDirectory)
                listResult = list(enumerate(sftp.listdir()))
                for (index,domain) in listResult:
                    print(' [{:^4}] {}'.format(index,domain))

                print('')
                domainIndex = int(input(' Enter The Index Number : '))
                print('')

                domainName = listResult[domainIndex][1]
                print('hacking')
                fun_makeHeader('All backups of '+domainName)

                sftp.chdir(domainName)                      
                archiveListResult = list(enumerate(sftp.listdir()))
                for (index,archiveName) in archiveListResult:
                    print('   [{:^4}] {}'.format(index,archiveName))
                print('')
                archiveIndex = int(input(' Enter The Archive Index Number : '))
                downloadArchiveName = archiveListResult[archiveIndex][1]
                print('')
                downloadLocation = input(' DownLoad Location : ')
                print(downloadLocation)
                if os.path.exists(downloadLocation):
                    print(' DownLoading '+downloadArchiveName)
                    print(sftp.pwd)
                    sftp.get(downloadArchiveName,localpath=os.path.join(downloadLocation,downloadArchiveName))
                    input('')
                else:
                    fun_makeMessage(' no such directory '+ downloadLocation)                        
            else:
                fun_makeMessage('Unable to complete the listing..!')  
    except:
        fun_makeMessage(' Unable to Connect To the Remote Host..!')       





while True:
    fun_makeHeader('python back-up script with sftp upload')
    print(' 1.Backup Domain.')
    print(' 2.List backup.')
    print(' 3.Quit')
    print('')
    operation = input(' Select An Operation : ')
    # Cheacking the variable is not empty:
    if operation and operation.isnumeric():
        operation = int(operation)
        if  operation == 1:
            fun_createBackup()
        elif operation == 2:
            fun_listBackup()
        elif operation == 3:
            print('')
            break
        else:
            fun_makeMessage(' Invalid Operation')
    else:
        fun_makeMessage(' Invalid Operation')

    
